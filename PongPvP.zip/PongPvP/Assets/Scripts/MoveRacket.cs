﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveRacket : MonoBehaviour
{
    public float speed = 30;
    public string axisY = "Vertical";
    //public string axisX = "Horizontal";

    void FixedUpdate()
    {
        //move vertically
        float y = Input.GetAxisRaw(axisY);
        GetComponent<Rigidbody2D>().velocity = new Vector2(0, y) * speed;
        
        //move horizontally
        //float x = Input.GetAxisRaw(axisX);
        //GetComponent<Rigidbody2D>().velocity = new Vector2(0, x) * speed;

    }
}
