﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetPosition : MonoBehaviour
{
    public int difference = 0;
    public Rigidbody2D player;

    // Update is called once per frame
    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().transform.position = new Vector3(player.position.x + difference, player.position.y);
    }
}
