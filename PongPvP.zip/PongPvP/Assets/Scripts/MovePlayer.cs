﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlayer : MonoBehaviour
{
    //public Rigidbody2D m_Rigidbody2D;
    //private Vector3 m_Velocity = Vector3.zero;
    //[Range(0, .3f)] [SerializeField] private float m_MovementSmoothing = .05f;

    public Collider2D ground;
    public Collider2D ball;
    public float m_JumpForce = 1200;
    public float speed = 30;

    public string axisX = "Horizontal";
    //public bool jump = false;
    //public bool jumping = false;
    private float x = 0;

    public bool grounded_check = true;
    public string jump_input = "Jump";

    private void Start()
    {
        Physics2D.IgnoreCollision(GetComponent<Collider2D>(), ball);
    }


    private void Update()
    {
        x = Input.GetAxisRaw(axisX);
        

        //if(GetComponent<Rigidbody2D>().velocity.y == 0)
        //{
        //    grounded_check = true; //.IsTouching(ground or stable in air);
        //}
        //else
        //{
        //    grounded_check = false;
        //}

        //if (grounded_check)
        //{
        //    jumping = false;
        //}
        
        //if (Input.GetButton(jump_input) && !jumping && grounded_check)
        //{
        //    jump = true;
        //}
        //else
        //{
        //    jump = false;
        //}

        Jump();
        Vector3 Movement = new Vector3(Input.GetAxis(axisX), 0f, 0f);
        transform.position += Movement * Time.deltaTime * speed;
    }

    

    void Jump()
    {
        if (Input.GetButtonDown(jump_input) && grounded_check == true)
        {
            // Add a vertical force to the player.
            GetComponent<Rigidbody2D>().AddForce(new Vector2(0f, m_JumpForce), ForceMode2D.Impulse);    //AddForce(new Vector2(0f, m_JumpForce), ForceMode2D.Impulse);//, ForceMode2D.Impulse);
            //jump = false;
            //jumping = true;
        }
    }
    

}
